﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public partial class UICharacterSelection
{
    // Start is called before the first frame update
    public UI_CharacterCreation uiCharacterCreationExtented;
    public Button createButtonExtend;

}
