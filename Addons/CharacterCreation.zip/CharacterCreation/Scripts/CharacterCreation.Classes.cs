
using UnityEngine;
using UnityEngine.UI;

// CharacterCreationClass

[System.Serializable]
public partial class CharacterCreationClass
{
    public Button button;
    public Text label;
    [HideInInspector] public int prefabID;
}
