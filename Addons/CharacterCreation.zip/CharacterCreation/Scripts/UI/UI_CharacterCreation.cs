using Mirror;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using uMMORPG;

public class UI_CharacterCreation : MonoBehaviour
{
    [Header("Panels")]
    public GameObject panel;
    public GameObject centerPanel2;

    [Header("Class Selection")]
    public Transform content;
    public UI_CharacterSlot characterSlot;

    [Header("Camera")]
    public Transform creationCameraLocation;
    public Transform creationCameraHeadLocation;
    public bool lookAtCamera;

    [Header("Spawn")]
    public Transform SpawnPoint;

    [Header("Create")]
    public TMP_InputField nameInput;
    public Button createButton;
    public Button cancelButton;
    public Toggle gameMasterToggle;

    [Header("Customization UI")]
    public Button hairPrev;
    public Button hairNext;

    public Button beardPrev;
    public Button beardNext;

    public Button beard2Prev;
    public Button beard2Next;

    public Button eyesPrev;
    public Button eyesNext;

    public Button facePrev;
    public Button faceNext;

    public Button earsPrev;
    public Button earsNext;

    public Button browsPrev;
    public Button browsNext;

    public Button otherPrev;
    public Button otherNext;

    // ------------------------
    // Internal state
    // ------------------------
    NetworkManagerMMO manager;
    List<Player> players;
    int classIndex;
    bool bInit;
    GameObject go;

    // visual indices
    int hairIndex;
    int beardIndex;
    int beard2Index;
    int eyesIndex;
    int faceIndex;
    int earsIndex;
    int browsIndex;
    int otherIndex;

    void Awake()
    {
        manager = NetworkManager.singleton as NetworkManagerMMO;
        panel.SetActive(false);
    }

    // =====================================================
    // SHOW / HIDE
    // =====================================================
    public void Show()
    {
#if !UNITY_SERVER
        if (panel.activeSelf)
            return;

        if (creationCameraLocation != null)
        {
            Camera.main.transform.position = creationCameraLocation.position;
            Camera.main.transform.rotation = creationCameraLocation.rotation;
        }

        players = manager.playerClasses;
        if (players == null || players.Count == 0)
            return;

        if (centerPanel2 != null)
            centerPanel2.SetActive(false);

        UIUtils.BalancePrefabs(characterSlot.gameObject, players.Count, content);
        for (int i = 0; i < players.Count; i++)
        {
            UI_CharacterSlot slot = content.GetChild(i).GetComponent<UI_CharacterSlot>();
            slot.characterName.text = players[i].name;

            int idx = i;
            slot.button.onClick.SetListener(() => SetCharacterClass(idx));
            slot.button.gameObject.SetActive(true);
        }

        SetCharacterClass(0);

        createButton.onClick.SetListener(CreateCharacter);
        cancelButton.onClick.SetListener(Hide);

        panel.SetActive(true);
        bInit = true;

        // wire customization UI
        WireSlotButtons(VisualSlot.Hair,   hairPrev,   hairNext);
        WireSlotButtons(VisualSlot.Beard,  beardPrev,  beardNext);
        WireSlotButtons(VisualSlot.Beard2, beard2Prev, beard2Next);
        WireSlotButtons(VisualSlot.Eyes,   eyesPrev,   eyesNext);
        WireSlotButtons(VisualSlot.Face,   facePrev,   faceNext);
        WireSlotButtons(VisualSlot.Ears,   earsPrev,   earsNext);
        WireSlotButtons(VisualSlot.Brows,  browsPrev,  browsNext);
        WireSlotButtons(VisualSlot.Other,  otherPrev,  otherNext);
#endif
    }

    public void Hide()
    {
        if (SpawnPoint != null && SpawnPoint.childCount > 0)
            Destroy(SpawnPoint.GetChild(0).gameObject);

        panel.SetActive(false);
        bInit = false;

        if (manager != null && manager.selectionCameraLocation != null)
        {
            Camera.main.transform.position = manager.selectionCameraLocation.position;
            Camera.main.transform.rotation = manager.selectionCameraLocation.rotation;
        }
    }

    void Update()
    {
        if (!bInit) return;

        if (manager != null)
            createButton.interactable = manager.IsAllowedCharacterName(nameInput.text);

        if (gameMasterToggle != null)
            gameMasterToggle.gameObject.SetActive(NetworkServer.activeHost);
    }

    // =====================================================
    // CLASS / PREVIEW
    // =====================================================
    void SetCharacterClass(int idx)
    {
        classIndex = idx;

        if (creationCameraLocation != null)
        {
            Camera.main.transform.position = creationCameraLocation.position;
            Camera.main.transform.rotation = creationCameraLocation.rotation;
        }

        if (SpawnPoint.childCount > 0)
            Destroy(SpawnPoint.GetChild(0).gameObject);

        go = Instantiate(players[classIndex].gameObject, SpawnPoint.position, SpawnPoint.rotation);
        go.transform.SetParent(SpawnPoint, false);

        if (lookAtCamera && creationCameraLocation != null)
            go.transform.LookAt(creationCameraLocation);

        Player player = go.GetComponent<Player>();
        player.nameOverlay.gameObject.SetActive(false);

        // init equipment slots (including hidden visual slots)
        PlayerEquipment src = (PlayerEquipment)players[classIndex].equipment;
        PlayerEquipment eq = (PlayerEquipment)player.equipment;

        eq.slots.Clear();
        for (int i = 0; i < src.slotInfo.Length; i++)
        {
            EquipmentInfo info = src.slotInfo[i];
            ItemSlot slot = new ItemSlot();

            if (info.defaultItem.item != null)
                slot = new ItemSlot(new Item(info.defaultItem.item), info.defaultItem.amount);

            eq.slots.Add(slot);
            eq.RefreshLocation(i);
        }
    }

    // =====================================================
    // CUSTOMIZATION UI
    // =====================================================
    void WireSlotButtons(int slot, Button prev, Button next)
    {
        if (prev == null || next == null)
            return;

        bool show = HasMultipleMeshes(slot);
        prev.gameObject.SetActive(show);
        next.gameObject.SetActive(show);

        if (!show)
            return;

        prev.onClick.SetListener(() =>
        {
            int cur = GetIndex(slot);
            int ni = PrevIndex(cur, slot);
            SetIndex(slot, ni);
            SetPreviewVisual(slot, ni);
        });

        next.onClick.SetListener(() =>
        {
            int cur = GetIndex(slot);
            int ni = NextIndex(cur, slot);
            SetIndex(slot, ni);
            SetPreviewVisual(slot, ni);
        });
    }

    bool HasMultipleMeshes(int slot)
    {
        return GetMeshCount(slot) > 1;
    }

    int GetMeshCount(int slot)
    {
        if (go == null) return 0;

        PlayerEquipment eq = (PlayerEquipment)go.GetComponent<Player>().equipment;
        if (slot < 0 || slot >= eq.slotInfo.Length) return 0;

        EquipmentInfo info = eq.slotInfo[slot];
        return info.mesh != null ? info.mesh.Length : 0;
    }

    int NextIndex(int current, int slot)
    {
        int max = GetMeshCount(slot);
        if (max <= 0) return 0;
        return (current + 1) % max;
    }

    int PrevIndex(int current, int slot)
    {
        int max = GetMeshCount(slot);
        if (max <= 0) return 0;
        return (current - 1 + max) % max;
    }

    int GetIndex(int slot)
    {
        switch (slot)
        {
            case VisualSlot.Hair:   return hairIndex;
            case VisualSlot.Beard:  return beardIndex;
            case VisualSlot.Beard2: return beard2Index;
            case VisualSlot.Eyes:   return eyesIndex;
            case VisualSlot.Face:   return faceIndex;
            case VisualSlot.Ears:   return earsIndex;
            case VisualSlot.Brows:  return browsIndex;
            case VisualSlot.Other:  return otherIndex;
            default: return 0;
        }
    }

    void SetIndex(int slot, int value)
    {
        switch (slot)
        {
            case VisualSlot.Hair:   hairIndex   = value; break;
            case VisualSlot.Beard:  beardIndex  = value; break;
            case VisualSlot.Beard2: beard2Index = value; break;
            case VisualSlot.Eyes:   eyesIndex   = value; break;
            case VisualSlot.Face:   faceIndex   = value; break;
            case VisualSlot.Ears:   earsIndex   = value; break;
            case VisualSlot.Brows:  browsIndex  = value; break;
            case VisualSlot.Other:  otherIndex  = value; break;
        }
    }

    void SetPreviewVisual(int slotIndex, int meshIndex)
    {
        if (go == null) return;

        Player player = go.GetComponent<Player>();
        PlayerEquipment eq = (PlayerEquipment)player.equipment;

        while (eq.slots.Count <= slotIndex)
            eq.slots.Add(new ItemSlot());

        EquipmentItem fake = ScriptableObject.CreateInstance<EquipmentItem>();
        fake.meshIndex = new int[] { meshIndex };

        eq.slots[slotIndex] = new ItemSlot(new Item(fake), 1);
        eq.RefreshLocation(slotIndex);
    }

    // =====================================================
    // CREATE (SAVE COMES NEXT)
    // =====================================================
    void CreateCharacter()
    {
        if (string.IsNullOrWhiteSpace(nameInput.text))
            return;

        CharacterCreateMsg msg = new CharacterCreateMsg
        {
            name = nameInput.text,
            classIndex = classIndex
        };

        NetworkClient.Send(msg);
        Hide();
    }

    public bool IsVisible()
    {
        return panel.activeSelf;
    }
}
