using UnityEngine;
using UnityEngine.UI;
using uMMORPG;

public class UI_TraitSlot : MonoBehaviour
{
    public UIShowToolTip tooltip;
    public Button button;
    public Image image;
}
