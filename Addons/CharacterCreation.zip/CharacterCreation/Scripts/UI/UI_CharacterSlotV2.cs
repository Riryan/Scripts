using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UI_CharacterSlotV2 : MonoBehaviour
{
    public Image characterImage;
    public TMP_Text characterName;
    public TMP_Text characterLevel;
    public TMP_Text characterClasse;
    public Button button;
    public GameObject isGM;
}
