using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UI_CharacterSlot : MonoBehaviour
{
    public TMP_Text characterName;
    public Button button;
}
